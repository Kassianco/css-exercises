# GSAP cards
Boilerplate card design for the GreenSock animation exercise.

The purpose of this exercise is to create meaningful animations between the three cards.

We will be using the following GreenSock libraries:
- TweenMax
- TimelineMax

GreenSock documentation:
https://greensock.com/docs/
